﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;
using System.Windows.Forms;
using Proyecto_Integrador.Controller;
using Proyecto_Integrador.Models;

namespace Proyecto_Integrador.Views
{
    public internal class FormFactura : Form
    {
        private DataGridView dgvCotizaciones;
        private DataGridView dgvFacturas;
        private Button btnConvertir;
        private Button btnImprimir;
        private Button btnFiltrar;
        private DateTimePicker dtpDesde;
        private DateTimePicker dtpHasta;
        private ComboBox cmbCliente;
        private ComboBox cmbEstado;

        private readonly FacturaController _facCtrl;
        private readonly CotizacionController _cotCtrl;
        private readonly ClienteController _cliCtrl;
        private readonly Usuario _usuario;

        public FormFactura(FacturaController fc, CotizacionController cc, ClienteController cl, Usuario u)
        {
            _facCtrl = fc;
            _cotCtrl = cc;
            _cliCtrl = cl;
            _usuario = u;
            InitializeComponent();
            RefrescarCotizaciones();
            RefrescarFacturas(null);
        }

        private void InitializeComponent()
        {
            this.Text = "Gestión de Facturas";
            this.Size = new Size(950, 650);
            this.StartPosition = FormStartPosition.CenterParent;

            TabControl tabs = new TabControl();
            tabs.Dock = DockStyle.Fill;

            // ─── Tab 1: Convertir cotización ───
            TabPage tabConv = new TabPage("Convertir Cotización");

            dgvCotizaciones = new DataGridView();
            dgvCotizaciones.Dock = DockStyle.Fill;
            dgvCotizaciones.ReadOnly = true;
            dgvCotizaciones.AllowUserToAddRows = false;
            dgvCotizaciones.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCotizaciones.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            DataGridViewTextBoxColumn c1 = new DataGridViewTextBoxColumn(); c1.Name = "Fecha"; c1.HeaderText = "Fecha";
            DataGridViewTextBoxColumn c2 = new DataGridViewTextBoxColumn(); c2.Name = "Cliente"; c2.HeaderText = "Cliente";
            DataGridViewTextBoxColumn c3 = new DataGridViewTextBoxColumn(); c3.Name = "Material"; c3.HeaderText = "Material";
            DataGridViewTextBoxColumn c4 = new DataGridViewTextBoxColumn(); c4.Name = "Volumen"; c4.HeaderText = "m³";
            DataGridViewTextBoxColumn c5 = new DataGridViewTextBoxColumn(); c5.Name = "Total"; c5.HeaderText = "Total ($)";
            DataGridViewTextBoxColumn c6 = new DataGridViewTextBoxColumn(); c6.Name = "Estado"; c6.HeaderText = "Estado";
            dgvCotizaciones.Columns.Add(c1); dgvCotizaciones.Columns.Add(c2); dgvCotizaciones.Columns.Add(c3);
            dgvCotizaciones.Columns.Add(c4); dgvCotizaciones.Columns.Add(c5); dgvCotizaciones.Columns.Add(c6);

            btnConvertir = new Button();
            btnConvertir.Text = "Convertir Cotización Seleccionada a Factura";
            btnConvertir.Dock = DockStyle.Bottom;
            btnConvertir.Height = 38;
            btnConvertir.BackColor = Color.FromArgb(34, 120, 50);
            btnConvertir.ForeColor = Color.White;
            btnConvertir.FlatStyle = FlatStyle.Flat;
            btnConvertir.Click += new EventHandler(BtnConvertir_Click);

            tabConv.Controls.Add(dgvCotizaciones);
            tabConv.Controls.Add(btnConvertir);

            // ─── Tab 2: Historial / Filtros ───
            TabPage tabHist = new TabPage("Historial de Facturas");

            Panel panelFiltros = new Panel();
            panelFiltros.Dock = DockStyle.Top;
            panelFiltros.Height = 65;
            panelFiltros.Padding = new Padding(8);

            Label lDesde = new Label(); lDesde.Text = "Desde:"; lDesde.Location = new Point(8, 16); lDesde.AutoSize = true;
            panelFiltros.Controls.Add(lDesde);

            dtpDesde = new DateTimePicker();
            dtpDesde.Location = new Point(58, 12);
            dtpDesde.Width = 120;
            dtpDesde.Format = DateTimePickerFormat.Short;
            panelFiltros.Controls.Add(dtpDesde);

            Label lHasta = new Label(); lHasta.Text = "Hasta:"; lHasta.Location = new Point(188, 16); lHasta.AutoSize = true;
            panelFiltros.Controls.Add(lHasta);

            dtpHasta = new DateTimePicker();
            dtpHasta.Location = new Point(238, 12);
            dtpHasta.Width = 120;
            dtpHasta.Format = DateTimePickerFormat.Short;
            dtpHasta.Value = DateTime.Now;
            panelFiltros.Controls.Add(dtpHasta);

            Label lCliente = new Label(); lCliente.Text = "Cliente:"; lCliente.Location = new Point(368, 16); lCliente.AutoSize = true;
            panelFiltros.Controls.Add(lCliente);

            cmbCliente = new ComboBox();
            cmbCliente.Location = new Point(418, 12);
            cmbCliente.Width = 150;
            cmbCliente.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCliente.Items.Add("Todos");
            foreach (Cliente cl in _cliCtrl.ObtenerClientes())
                cmbCliente.Items.Add(cl);
            cmbCliente.DisplayMember = "Nombre";
            cmbCliente.SelectedIndex = 0;
            panelFiltros.Controls.Add(cmbCliente);

            Label lEstado = new Label(); lEstado.Text = "Estado:"; lEstado.Location = new Point(578, 16); lEstado.AutoSize = true;
            panelFiltros.Controls.Add(lEstado);

            cmbEstado = new ComboBox();
            cmbEstado.Location = new Point(628, 12);
            cmbEstado.Width = 100;
            cmbEstado.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbEstado.Items.Add("Todos");
            cmbEstado.Items.Add("Activa");
            cmbEstado.Items.Add("Inactiva");
            cmbEstado.SelectedIndex = 0;
            panelFiltros.Controls.Add(cmbEstado);

            btnFiltrar = new Button();
            btnFiltrar.Text = "Filtrar";
            btnFiltrar.Location = new Point(736, 10);
            btnFiltrar.Width = 70;
            btnFiltrar.Height = 28;
            btnFiltrar.FlatStyle = FlatStyle.Flat;
            btnFiltrar.Click += new EventHandler(BtnFiltrar_Click);
            panelFiltros.Controls.Add(btnFiltrar);

            dgvFacturas = new DataGridView();
            dgvFacturas.Dock = DockStyle.Fill;
            dgvFacturas.ReadOnly = true;
            dgvFacturas.AllowUserToAddRows = false;
            dgvFacturas.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvFacturas.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            DataGridViewTextBoxColumn f1 = new DataGridViewTextBoxColumn(); f1.Name = "Fecha"; f1.HeaderText = "Fecha";
            DataGridViewTextBoxColumn f2 = new DataGridViewTextBoxColumn(); f2.Name = "Cliente"; f2.HeaderText = "Cliente";
            DataGridViewTextBoxColumn f3 = new DataGridViewTextBoxColumn(); f3.Name = "Material"; f3.HeaderText = "Material";
            DataGridViewTextBoxColumn f4 = new DataGridViewTextBoxColumn(); f4.Name = "Volumen"; f4.HeaderText = "m³";
            DataGridViewTextBoxColumn f5 = new DataGridViewTextBoxColumn(); f5.Name = "Total"; f5.HeaderText = "Total ($)";
            DataGridViewTextBoxColumn f6 = new DataGridViewTextBoxColumn(); f6.Name = "Estado"; f6.HeaderText = "Estado";
            dgvFacturas.Columns.Add(f1); dgvFacturas.Columns.Add(f2); dgvFacturas.Columns.Add(f3);
            dgvFacturas.Columns.Add(f4); dgvFacturas.Columns.Add(f5); dgvFacturas.Columns.Add(f6);

            btnImprimir = new Button();
            btnImprimir.Text = "Imprimir Factura Seleccionada";
            btnImprimir.Dock = DockStyle.Bottom;
            btnImprimir.Height = 32;
            btnImprimir.FlatStyle = FlatStyle.Flat;
            btnImprimir.Click += new EventHandler(BtnImprimir_Click);

            if (_usuario.rol == Rol.Administrador)
            {
                Button btnEstado = new Button();
                btnEstado.Text = "Cambiar Estado (Activa/Inactiva)";
                btnEstado.Dock = DockStyle.Bottom;
                btnEstado.Height = 30;
                btnEstado.FlatStyle = FlatStyle.Flat;
                btnEstado.Click += new EventHandler(BtnCambiarEstado_Click);
                tabHist.Controls.Add(btnEstado);
            }

            tabHist.Controls.Add(btnImprimir);
            tabHist.Controls.Add(dgvFacturas);
            tabHist.Controls.Add(panelFiltros);

            tabs.TabPages.Add(tabConv);
            tabs.TabPages.Add(tabHist);
            this.Controls.Add(tabs);
        }

        private void RefrescarCotizaciones()
        {
            dgvCotizaciones.Rows.Clear();
            foreach (Cotizacion c in _cotCtrl.ObtenerCotizaciones())
            {
                dgvCotizaciones.Rows.Add(
                    c.Fecha.ToString("dd/MM/yyyy"),
                    c.NombreCliente,
                    c.NombreMaterial,
                    c.VolumenM3.ToString("F2"),
                    c.Total.ToString("N0"),
                    c.Estado);
            }
        }

        private void RefrescarFacturas(List<Factura> lista)
        {
            dgvFacturas.Rows.Clear();

            if (lista == null)
                lista = _facCtrl.ObtenerFacturas();

            foreach (Factura f in lista)
            {
                dgvFacturas.Rows.Add(
                    f.Fecha.ToString("dd/MM/yyyy"),
                    f.NombreCliente,
                    f.MaterialNombre,
                    f.VolumenM3.ToString("F2"),
                    f.Total.ToString("N0"),
                    f.Estado);
            }
        }

        private void BtnConvertir_Click(object sender, EventArgs e)
        {
            if (dgvCotizaciones.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una cotización de la lista.", "Aviso");
                return;
            }

            int idx = dgvCotizaciones.SelectedRows[0].Index;
            List<Cotizacion> lista = _cotCtrl.ObtenerCotizaciones();

            if (idx >= lista.Count)
                return;

            Cotizacion cot = lista[idx];
            var (ok, fac, msg) = _facCtrl.ConvertirDesde(cot);

            if (ok)
            {
                MessageBox.Show(msg, "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefrescarFacturas(null);
            }
            else
            {
                MessageBox.Show(msg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnFiltrar_Click(object sender, EventArgs e)
        {
            string clienteId = null;

            if (cmbCliente.SelectedItem is Cliente clienteSeleccionado)
                clienteId = clienteSeleccionado.id;

            EstadoFactura? estado = null;
            if (cmbEstado.SelectedIndex == 1)
                estado = EstadoFactura.Activa;
            else if (cmbEstado.SelectedIndex == 2)
                estado = EstadoFactura.Inactiva;

            List<Factura> resultado = _facCtrl.Filtrar(clienteId, dtpDesde.Value.Date, dtpHasta.Value.Date.AddDays(1), estado);
            RefrescarFacturas(resultado);
        }

        private void BtnCambiarEstado_Click(object sender, EventArgs e)
        {
            if (dgvFacturas.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una factura de la lista.", "Aviso");
                return;
            }

            int idx = dgvFacturas.SelectedRows[0].Index;
            List<Factura> lista = _facCtrl.ObtenerTodas();

            if (idx >= lista.Count)
                return;

            Factura f = lista[idx];
            EstadoFactura nuevoEstado;

            if (f.Estado == EstadoFactura.Activa)
                nuevoEstado = EstadoFactura.Inactiva;
            else
                nuevoEstado = EstadoFactura.Activa;

            _facCtrl.CambiarEstado(f.Id, nuevoEstado);
            RefrescarFacturas(null);
        }

        // RF30 - Imprimir
        private void BtnImprimir_Click(object sender, EventArgs e)
        {
            if (dgvFacturas.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una factura de la lista.", "Aviso");
                return;
            }

            int idx = dgvFacturas.SelectedRows[0].Index;
            List<Factura> lista = _facCtrl.ObtenerTodas();

            if (idx >= lista.Count)
                return;

            Factura facturaSeleccionada = lista[idx];

            PrintDocument pd = new PrintDocument();
            pd.PrintPage += delegate (object s, PrintPageEventArgs ev)
            {
                ImprimirFactura(ev, facturaSeleccionada);
            };

            PrintPreviewDialog preview = new PrintPreviewDialog();
            preview.Document = pd;
            preview.ShowDialog(this);
        }

        private void ImprimirFactura(PrintPageEventArgs e, Factura f)
        {
            Graphics g = e.Graphics;
            Font fontTitulo = new Font("Arial", 14, FontStyle.Bold);
            Font fontNormal = new Font("Courier New", 10);
            Font fontTotal = new Font("Arial", 13, FontStyle.Bold);

            int y = 50;
            g.DrawString("=== FACTURA ===", fontTitulo, Brushes.Black, 220, y); y += 35;
            g.DrawString("ID Factura:  " + f.Id, fontNormal, Brushes.Black, 50, y); y += 22;
            g.DrawString("ID Cotiz.:   " + f.CotizacionId, fontNormal, Brushes.Black, 50, y); y += 22;
            g.DrawString("Fecha:       " + f.Fecha.ToString("dd/MM/yyyy HH:mm"), fontNormal, Brushes.Black, 50, y); y += 22;
            g.DrawString("Cliente:     " + f.NombreCliente, fontNormal, Brushes.Black, 50, y); y += 22;
            g.DrawString("Material:    " + f.MaterialNombre, fontNormal, Brushes.Black, 50, y); y += 22;
            g.DrawString("Volumen:     " + f.VolumenM3.ToString("F4") + " m³", fontNormal, Brushes.Black, 50, y); y += 22;
            g.DrawString("Costo x m³:  $" + f.CostoPorM3.ToString("N0"), fontNormal, Brushes.Black, 50, y); y += 35;
            g.DrawString("TOTAL: $" + f.Total.ToString("N0"), fontTotal, Brushes.Black, 50, y);
        }
    }
}
